<h1 class="mb-4 fw-bold">Hallo, {{ auth()->user()->name }}</h1>
